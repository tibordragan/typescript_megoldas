// 1. feladat //
function MegtettUt(sebesseg, ido) {
    var eredmeny = sebesseg * ido; //sebesseg km/h-ban -- ido órában
    return eredmeny;
}
console.log(MegtettUt(60, 0.5));

// 2. feladat //
function HosegriadoSzint(nap1, nap2, nap3) {
    if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27) {
        return 3;
    }
    else if (nap1 >= 25 && nap2 >= 25 && nap3 >= 25) {
        return 2;
    }
    else if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) {
        return 1;
    }
    else {
        return 0;
    }
}
// 3. feladat //
function OszthatoSzamok(oszto, vizsgaltTomb) {
    var eredmeny = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] != 0) {
            if (vizsgaltTomb[i] % 2 == 0) {
                eredmeny++;
            }
        }
    }
    return eredmeny;
}
// 5. feladat //
function LeetKod(vizsgaltSzoveg) {
    var eredmenyString = vizsgaltSzoveg;
    eredmenyString = eredmenyString.replaceAll('i', '1');
    eredmenyString = eredmenyString.replaceAll('I', '1');
    eredmenyString = eredmenyString.replaceAll('o', '0');
    eredmenyString = eredmenyString.replaceAll('O', '0');
    eredmenyString = eredmenyString.replaceAll('a', '4');
    eredmenyString = eredmenyString.replaceAll('A', '4');
    eredmenyString = eredmenyString.replaceAll('e', '3');
    eredmenyString = eredmenyString.replaceAll('E', '3');
    return eredmenyString;
}
console.log(LeetKod("iIoOaAeE"));
