// 1. feladat //

function MegtettUt(sebesseg: number, ido: number): number {
    let eredmeny: number = sebesseg * ido; //sebesseg km/h-ban -- ido órában
    return eredmeny;
}
console.log(MegtettUt(60, 0.5));

// 2. feladat //

function HosegriadoSzint(nap1: number, nap2: number, nap3: number): number {
    if (nap1 >= 27 && nap2 >= 27 && nap3 >= 27) {
        return 3;
    }
    else if (nap1 >= 25 && nap2 >= 25 && nap3 >= 25) {
        return 2;
    }
    else if (nap1 >= 25 || nap2 >= 25 || nap3 >= 25) {
        return 1;
    }
    else { return 0; }
}


// 3. feladat //

function OszthatoSzamok(oszto: number, vizsgaltTomb: number[]): number {
    let eredmeny: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] != 0) {
            if (vizsgaltTomb[i] % 2 == 0) {
                eredmeny++;
            }
        }
    }
    return eredmeny;
}


// 5. feladat //

function LeetKod(vizsgaltSzoveg: string): string {
    let eredmenyString: string = vizsgaltSzoveg;
    eredmenyString = eredmenyString.replaceAll('i', '1');
    eredmenyString = eredmenyString.replaceAll('I', '1');
    eredmenyString = eredmenyString.replaceAll('o', '0');
    eredmenyString = eredmenyString.replaceAll('O', '0');
    eredmenyString = eredmenyString.replaceAll('a', '4');
    eredmenyString = eredmenyString.replaceAll('A', '4');
    eredmenyString = eredmenyString.replaceAll('e', '3');
    eredmenyString = eredmenyString.replaceAll('E', '3');
    return eredmenyString;
}
console.log(LeetKod("iIoOaAeE"));